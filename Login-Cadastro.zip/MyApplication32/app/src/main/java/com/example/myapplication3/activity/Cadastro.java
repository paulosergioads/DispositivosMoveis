package com.example.myapplication3.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication3.R;
import com.example.myapplication3.util.ConfigBd;
import com.google.firebase.auth.FirebaseAuth;

public class Cadastro extends AppCompatActivity {

    Usuario usuario;
    FirebaseAuth autenticacao;
    EditText campoNome, campoEmail, campoSenha;
    Button botaoCadastrar;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastro);

        iniciar();
    }

    private void iniciar (){
        campoNome = findViewById(R.id.username);
        campoEmail = findViewById(R.id.email);
        campoSenha = findViewById(R.id.senha);
        botaoCadastrar = findViewById(R.id.button);
    }

    private  void validaCampos(View v){

        String nome = campoNome.getText().toString();
        String email = campoEmail.getText().toString();
        String senha = campoSenha.getText().toString();
        
        if(!nome.isEmpty()){
            if(!email.isEmpty()){

                if (!senha.isEmpty()){
                    Usuario usuario = new Usuario();

                    usuario.setNome(nome);
                    usuario.setEmail(email);
                    usuario.setSenha(senha);

                    cadastrarUsuario();

                }   else {
                    Toast.makeText(this, "Prencha a Senha", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Prencha o Email", Toast.LENGTH_SHORT).show();
            }
            
        }else {
            Toast.makeText(this, "Prencha o Nome", Toast.LENGTH_SHORT).show();
        }

    }

    private void cadastrarUsuario(){

        autenticacao = ConfigBd.FirebaseAutenticacao();
        autenticacao.createUserWithEmailAndPassword(
                usuario.get

        )

    }
}