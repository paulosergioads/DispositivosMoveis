package com.example.myapplication3.conexao;

import android.os.StrictMode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexao {

    public static Connection conectar() throws ClassNotFoundException, SQLException {

        StrictMode.ThreadPolicy politica;
        politica = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(politica);

        Class.forName("net.sourceforge.jtds.jdbc.Driver");

        String ip = "10.0.0.111:1433";
        String db = "";
        String user = "";
        String senha = "";
        String connString = "jdbc.jtds:sqlserver://"+ip+";databaseName="+db+";user="+user+";password="+senha+";";
        Connection conn = DriverManager.getConnection(connString);
        return  null;
    }
}
